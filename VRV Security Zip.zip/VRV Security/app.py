from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt

app = Flask(__name__)

# Step 1: Configure the Application and Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'super-secret-key'  # Change to a strong secret key

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

# Step 2: Define the User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

# Initialize Database
with app.app_context():
    db.create_all()

# Step 3: Home Route
@app.route('/')
def home():
    if 'username' in session:
        return render_template('dashboard.html', username=session['username'])
    return render_template('index.html')

# Step 4: User Registration
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        if User.query.filter_by(username=username).first():
            return 'User already exists!'

        new_user = User(username=username, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        return redirect(url_for('login'))

    return render_template('register.html')

# Step 5: User Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()

        if user and bcrypt.check_password_hash(user.password, password):
            session['username'] = username
            return redirect(url_for('home'))

        return 'Invalid credentials!'

    return render_template('login.html')

# Step 6: User Logout
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

# Step 7: HTML Templates
# Create a folder named "templates" in the same directory as this script and add the following HTML files:

# index.html
# <!DOCTYPE html>
# <html>
# <head>
#     <title>Home</title>
# </head>
# <body>
#     <h1>Welcome to the Website!</h1>
#     <a href="/login">Login</a> | <a href="/register">Register</a>
# </body>
# </html>

# register.html
# <!DOCTYPE html>
# <html>
# <head>
#     <title>Register</title>
# </head>
# <body>
#     <h1>Register</h1>
#     <form method="POST">
#         <label>Username:</label>
#         <input type="text" name="username" required><br>
#         <label>Password:</label>
#         <input type="password" name="password" required><br>
#         <button type="submit">Register</button>
#     </form>
#     <a href="/login">Already have an account? Login</a>
# </body>
# </html>

# login.html
# <!DOCTYPE html>
# <html>
# <head>
#     <title>Login</title>
# </head>
# <body>
#     <h1>Login</h1>
#     <form method="POST">
#         <label>Username:</label>
#         <input type="text" name="username" required><br>
#         <label>Password:</label>
#         <input type="password" name="password" required><br>
#         <button type="submit">Login</button>
#     </form>
#     <a href="/register">Don't have an account? Register</a>
# </body>
# </html>

# dashboard.html
# <!DOCTYPE html>
# <html>
# <head>
#     <title>Dashboard</title>
# </head>
# <body>
#     <h1>Welcome, {{ username }}!</h1>
#     <a href="/logout">Logout</a>
# </body>
# </html>

if __name__ == '__main__':
    app.run(debug=True)
